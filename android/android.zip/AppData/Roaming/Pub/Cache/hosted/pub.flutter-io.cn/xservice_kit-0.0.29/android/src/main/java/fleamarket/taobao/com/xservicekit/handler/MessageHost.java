package fleamarket.taobao.com.xservicekit.handler;

public interface MessageHost {
    String name();
}
