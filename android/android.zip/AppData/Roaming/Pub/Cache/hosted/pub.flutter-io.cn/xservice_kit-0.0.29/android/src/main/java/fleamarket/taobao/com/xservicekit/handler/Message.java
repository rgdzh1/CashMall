package fleamarket.taobao.com.xservicekit.handler;

public interface Message {
    String name();
    Object arguments();
    MessageHost Host();
}

