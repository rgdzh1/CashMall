package com.oklik.cashmall.constant;

public interface LinkParames {
    String linkParames = "linkParames";
}
