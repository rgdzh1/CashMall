package com.oklik.cashmall.deeplink;

import com.airbnb.deeplinkdispatch.DeepLinkModule;

@DeepLinkModule
public class LibraryDeepLinkModule {
}
