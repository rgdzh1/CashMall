package com.oklik.cashmall.constant;

public interface NativeKey {
    String MainKey = "main_path";
}
