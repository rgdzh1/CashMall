package com.oklik.cashmall.base;

public interface BaseView {
    int getContentId();

    void initData();

    void initListener();

}
