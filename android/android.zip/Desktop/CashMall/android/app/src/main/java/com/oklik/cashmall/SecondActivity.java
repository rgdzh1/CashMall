package com.oklik.cashmall;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.airbnb.deeplinkdispatch.DeepLink;
import com.oklik.cashmall.base.BaseActivity;
import com.oklik.cashmall.constant.NativePath;

import io.flutter.app.FlutterActivity;

@DeepLink(NativePath.SecondPath)
public class SecondActivity extends BaseActivity {


    @Override
    public int getContentId() {
        return R.layout.activity_second;
    }

    @Override
    public void initData() {

    }

    @Override
    public void initListener() {

    }
}
