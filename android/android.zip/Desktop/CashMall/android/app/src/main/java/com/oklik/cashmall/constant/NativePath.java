package com.oklik.cashmall.constant;

public interface NativePath {
    String SecondPath = "cashmall://SecondPath";
}

